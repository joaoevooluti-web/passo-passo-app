# Passo a Passo — app Android

Casca nativa em volta do `index.html` (v2.9.62). O app web continua sendo a fonte de tudo
(telas, metas, histórico, mapa); o Android acrescenta o que o navegador não consegue:

| Recurso | Como funciona |
|---|---|
| **GPS com a tela apagada** | Serviço em primeiro plano (`TrackService`) com notificação fixa "Caminhada em andamento". Guarda as leituras e o app web as processa em ordem, com o horário original de cada uma. |
| **Exportar GPX** | Botão "Exportar trajeto (GPX)" no detalhe de cada caminhada e "Exportar todos os trajetos" em Ajustes. No Android salva em `Downloads/Passo a Passo` e abre "Enviar para…" (Strava, Drive etc.). |
| **Backup e imagens** | "Exportar backup" e "Imagem para compartilhar" também salvam em `Downloads/Passo a Passo`. Importar backup abre o seletor de arquivos do Android. |
| **Notificações** | Metas e lembretes usam notificações do Android. |
| **Offline** | O `index.html` fica dentro do APK; só o mapa da cidade (Overpass) precisa de internet na 1ª vez. |

Sem bibliotecas externas: só o framework do Android (WebView, LocationManager, MediaStore).
Mínimo Android 10 (API 29).

## Como gerar o APK

**A) Android Studio** — *File ▸ Open* nesta pasta, aguarde o Gradle sincronizar e use *Build ▸ Build APK(s)*.
O arquivo sai em `app/build/outputs/apk/debug/app-debug.apk`.

**B) Linha de comando** (JDK 17 + Android SDK com a plataforma 34 instalados):

```
./gradlew assembleDebug
```

**C) GitHub Actions** — suba esta pasta como raiz de um repositório; o workflow
`.github/workflows/android.yml` compila e deixa o APK em *Actions ▸ (execução) ▸ Artifacts*.

Para instalar: copie o APK para o celular e permita "instalar apps desconhecidos" para o app de arquivos/navegador usado.
O APK de debug serve para uso pessoal; para a Play Store seria preciso uma chave própria e `targetSdk 35`.

## Atualizar o app web dentro do APK

```
./sync-web.sh /caminho/do/index.html
```

depois gere o APK de novo (e ajuste `versionName` em `app/build.gradle`).

## Seus dados (importante)

O app instalado guarda os dados **dentro dele**, separados do app que você usava no navegador/PWA.
Para levar o histórico: no app antigo, *Ajustes ▸ Exportar backup*; no novo, *Importar arquivo de backup*.
O mapa da cidade não entra no backup — ele é baixado de novo na primeira caminhada.

## Estrutura

```
app/src/main/java/app/passoapasso/
  MainActivity.java   WebView, permissões, seletor de arquivos, botão voltar
  Bridge.java         window.PassoNative (startTrack/drain/exportFile/exportB64/notify/lastKnown)
  TrackService.java   serviço de GPS em primeiro plano
  Track.java          buffer das leituras entre serviço e ponte
app/src/main/assets/index.html   app web embutido
```

A origem do WebView é `https://app.passoapasso.local` (constante `HOST`). **Não mude**: o localStorage e o
IndexedDB do app ficam presos a ela.
