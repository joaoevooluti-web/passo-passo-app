#!/bin/sh
# Copia o index.html mais novo do app web para dentro do app Android.
# Uso: ./sync-web.sh /caminho/para/index.html
set -e
SRC="${1:-../index.html}"
cp "$SRC" "$(dirname "$0")/app/src/main/assets/index.html"
echo "OK: $(grep -o "APP_VER='[^']*'" "$SRC" | head -1) copiado para app/src/main/assets/index.html"
