package app.passoapasso;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Ponte exposta ao JavaScript como window.PassoNative. O app web só a usa se ela existir;
 * no navegador comum tudo continua funcionando como antes.
 * Os métodos @JavascriptInterface rodam numa thread própria do WebView, não na principal.
 */
public class Bridge {
    private final MainActivity act;

    Bridge(MainActivity act) {
        this.act = act;
    }

    @JavascriptInterface
    public String version() {
        return "android-1";
    }

    /** Liga o GPS em primeiro plano. Devolve "ok" (ou "fail" para o app web cair no GPS do navegador). */
    @JavascriptInterface
    public String startTrack() {
        if (!Track.running) {          // caminhada nova: começa sem leituras antigas
            Track.clear();
            Track.status = "wait";
        }
        Track.want = true;
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                act.beginTrack();
            }
        });
        return "ok";
    }

    @JavascriptInterface
    public String stopTrack() {
        Track.want = false;
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                act.endTrack();
            }
        });
        return "ok";
    }

    /** JSON com o estado e as leituras acumuladas desde a última chamada. */
    @JavascriptInterface
    public String drain() {
        return Track.drain();
    }

    /**
     * Última posição conhecida do aparelho ("lat,lon,precisão"), de até 10 min atrás, ou "" se não houver.
     * Serve para desenhar o mapa já ao iniciar a caminhada, antes do primeiro sinal de GPS.
     */
    @JavascriptInterface
    public String lastKnown() {
        try {
            if (act.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return "";
            }
            LocationManager lm = (LocationManager) act.getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            String[] providers = {LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER,
                    LocationManager.PASSIVE_PROVIDER};
            for (String p : providers) {
                try {
                    Location l = lm.getLastKnownLocation(p);
                    if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
                } catch (Exception ignored) {
                    // provedor inexistente neste aparelho
                }
            }
            if (best == null || System.currentTimeMillis() - best.getTime() > 10 * 60 * 1000L) return "";
            return best.getLatitude() + "," + best.getLongitude() + "," + (best.hasAccuracy() ? best.getAccuracy() : 999);
        } catch (Exception e) {
            return "";
        }
    }

    /** Notificação comum (metas, lembretes) — as do navegador não existem no WebView. */
    @JavascriptInterface
    public String notify(String title, String body) {
        try {
            NotificationManager nm = (NotificationManager) act.getSystemService(Context.NOTIFICATION_SERVICE);
            Intent open = new Intent(act, MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            PendingIntent pi = PendingIntent.getActivity(act, 0, open,
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(act, MainActivity.CH_ALERT)
                    .setSmallIcon(R.drawable.ic_stat_walk)
                    .setContentTitle(title)
                    .setContentText(body)
                    .setStyle(new Notification.BigTextStyle().bigText(body))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            nm.notify((int) (System.currentTimeMillis() & 0x7fffffff), n);
            return "ok";
        } catch (Exception e) {
            return "err:" + e;
        }
    }

    /** Salva um arquivo de texto (GPX, backup JSON) em Downloads/Passo a Passo e abre "Enviar para…". */
    @JavascriptInterface
    public String exportFile(String name, String mime, String text) {
        return save(name, mime, text.getBytes(StandardCharsets.UTF_8));
    }

    /** Igual, para arquivos binários (imagens) enviados em base64. */
    @JavascriptInterface
    public String exportB64(String name, String mime, String b64) {
        try {
            return save(name, mime, Base64.decode(b64, Base64.DEFAULT));
        } catch (Exception e) {
            return "err:" + e;
        }
    }

    private String save(String name, String mime, byte[] data) {
        try {
            String safe = name.replaceAll("[\\\\/:*?\"<>|]", "_");
            ContentResolver cr = act.getContentResolver();
            ContentValues v = new ContentValues();
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, safe);
            // Com um tipo "application/gpx+xml" o Android pode trocar a extensão; octet-stream preserva o nome .gpx.
            v.put(MediaStore.MediaColumns.MIME_TYPE, mime.endsWith("+xml") ? "application/octet-stream" : mime);
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Passo a Passo");
            v.put(MediaStore.MediaColumns.IS_PENDING, 1);
            Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
            if (uri == null) return "err:insert";
            OutputStream os = cr.openOutputStream(uri);
            if (os == null) throw new IOException("sem stream");
            try {
                os.write(data);
            } finally {
                os.close();
            }
            v.clear();
            v.put(MediaStore.MediaColumns.IS_PENDING, 0);
            cr.update(uri, v, null, null);

            final Uri shared = uri;
            final String type = mime;
            act.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType(type);
                        send.putExtra(Intent.EXTRA_STREAM, shared);
                        send.setClipData(ClipData.newRawUri("", shared));
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        act.startActivity(Intent.createChooser(send, "Enviar para…"));
                    } catch (Exception ignored) {
                        // o arquivo já está salvo em Downloads; só não foi possível abrir o seletor
                    }
                }
            });
            return "ok:" + uri;
        } catch (Exception e) {
            return "err:" + e;
        }
    }
}
