package app.passoapasso;

import android.Manifest;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.widget.Toast;

/**
 * Serviço em primeiro plano que mantém o GPS ligado durante a caminhada, mesmo com a tela apagada
 * ou o app em segundo plano. Só guarda as leituras em Track; quem calcula distância, trajeto e metas
 * continua sendo o app web (index.html).
 */
public class TrackService extends Service implements LocationListener, SensorEventListener {
    private static final int NOTIF_ID = 1;
    private static final long MAX_MS = 12L * 60 * 60 * 1000; // trava de segurança: para sozinho após 12 h

    private LocationManager lm;
    private SensorManager sm;
    private PowerManager.WakeLock wl;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable cap = new Runnable() {
        @Override
        public void run() {
            stopSelf();
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        MainActivity.ensureChannels(this);

        Intent open = new Intent(this, MainActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder nb = new Notification.Builder(this, MainActivity.CH_WALK)
                .setSmallIcon(R.drawable.ic_stat_walk)
                .setContentTitle("Caminhada em andamento")
                .setContentText("Gravando seu trajeto. Toque para abrir.")
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .setCategory(Notification.CATEGORY_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= 31) {
            nb.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        try {
            startForeground(NOTIF_ID, nb.build(), ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION);
        } catch (Exception e) {
            // Ex.: o sistema não permitiu iniciar o serviço agora (app fora de primeiro plano)
            Track.status = "off";
            stopSelf();
            return START_NOT_STICKY;
        }
        Track.running = true;

        if (!Track.want) { // o app web já pediu para parar antes de o serviço terminar de subir
            stopSelf();
            return START_NOT_STICKY;
        }
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Track.status = "denied";
            stopSelf();
            return START_NOT_STICKY;
        }

        lm = (LocationManager) getSystemService(LOCATION_SERVICE);
        try {
            lm.removeUpdates(this);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, this, Looper.getMainLooper());
            Track.status = lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ? "ok" : "off";
        } catch (SecurityException e) {
            Track.status = "denied";
            stopSelf();
            return START_NOT_STICKY;
        } catch (Exception e) {
            Track.status = "off";
        }

        // passos pelo sensor do Android: continua contando com a tela apagada
        try {
            sm = (SensorManager) getSystemService(SENSOR_SERVICE);
            sm.unregisterListener(this);
            Sensor ss = sm.getDefaultSensor(Sensor.TYPE_STEP_DETECTOR);
            Track.stepsOk = ss != null
                    && checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) == PackageManager.PERMISSION_GRANTED
                    && sm.registerListener(this, ss, SensorManager.SENSOR_DELAY_NORMAL);
        } catch (Exception e) {
            Track.stepsOk = false;
        }

        if (wl == null) {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "passoapasso:walk");
            wl.setReferenceCounted(false);
        }
        if (!wl.isHeld()) wl.acquire(MAX_MS);
        handler.removeCallbacks(cap);
        handler.postDelayed(cap, MAX_MS);
        return START_NOT_STICKY;
    }

    @Override
    public void onLocationChanged(Location l) {
        // horário real da leitura no relógio do aparelho (a leitura pode ter alguns ms de atraso)
        long ageMs = (SystemClock.elapsedRealtimeNanos() - l.getElapsedRealtimeNanos()) / 1000000L;
        long ts = System.currentTimeMillis() - Math.max(0L, ageMs);
        Track.add(l.getLatitude(), l.getLongitude(),
                l.hasAccuracy() ? l.getAccuracy() : 999.0,
                l.hasSpeed() ? l.getSpeed() : -1.0,
                ts);
        Track.status = "ok";
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        Track.steps++; // o detector de passos gera um evento por passo
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onProviderEnabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) Track.status = "ok";
    }

    @Override
    public void onProviderDisabled(String provider) {
        if (LocationManager.GPS_PROVIDER.equals(provider)) {
            Track.status = "off";
            Toast.makeText(this, "Ative a localização (GPS) do Android para gravar o trajeto", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // não é mais chamado no Android 10+; mantido por compatibilidade com a interface
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(cap);
        try {
            if (lm != null) lm.removeUpdates(this);
        } catch (Exception ignored) {
        }
        try {
            if (sm != null) sm.unregisterListener(this);
        } catch (Exception ignored) {
        }
        Track.stepsOk = false;
        try {
            if (wl != null && wl.isHeld()) wl.release();
        } catch (Exception ignored) {
        }
        Track.running = false;
        if (!"denied".equals(Track.status)) Track.status = "off";
        super.onDestroy();
    }
}
