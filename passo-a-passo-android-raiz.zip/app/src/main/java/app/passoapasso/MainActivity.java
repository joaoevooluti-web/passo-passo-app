package app.passoapasso;

import android.Manifest;
import android.app.Activity;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Casca nativa do Passo a Passo: mostra o index.html embutido num WebView (funciona offline) e
 * adiciona o que o navegador não consegue: GPS com a tela apagada, salvar arquivos em Downloads,
 * notificações e o seletor de arquivos para importar backup.
 */
public class MainActivity extends Activity {
    /** Origem fixa e segura (https): o armazenamento do app (localStorage/IndexedDB) fica preso a ela. NÃO mude. */
    static final String HOST = "app.passoapasso.local";
    static final String START_URL = "https://" + HOST + "/index.html";
    static final String CH_WALK = "walk";
    static final String CH_ALERT = "alerts";
    private static final int REQ_PERM = 11;
    private static final int REQ_FILE = 12;

    private WebView web;
    private ValueCallback<Uri[]> fileCb;
    private boolean permPending;   // evita abrir dois diálogos de permissão ao mesmo tempo

    static void ensureChannels(Context c) {
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        NotificationChannel walk = new NotificationChannel(CH_WALK, "Caminhada em andamento",
                NotificationManager.IMPORTANCE_LOW);
        walk.setDescription("Aviso fixo enquanto o trajeto está sendo gravado");
        NotificationChannel alerts = new NotificationChannel(CH_ALERT, "Avisos e metas",
                NotificationManager.IMPORTANCE_DEFAULT);
        alerts.setDescription("Metas batidas e lembretes");
        nm.createNotificationChannel(walk);
        nm.createNotificationChannel(alerts);
    }

    @Override
    protected void onCreate(Bundle saved) {
        super.onCreate(saved);
        ensureChannels(this);

        web = new WebView(this);
        setContentView(web, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT));

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setGeolocationEnabled(true);                 // só para o plano B (GPS do navegador)
        s.setMediaPlaybackRequiresUserGesture(false);  // bipes das metas
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        // Tema escuro: o app web usa prefers-color-scheme; o WebView o liga quando o tema do Android (values-night) é escuro.
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);

        web.addJavascriptInterface(new Bridge(this), "PassoNative");
        web.setWebViewClient(new AppClient());
        web.setWebChromeClient(new AppChrome());
        web.loadUrl(START_URL);
    }

    // ---------- GPS em primeiro plano ----------

    private boolean hasLoc() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestPerms() {
        if (permPending) return;
        permPending = true;
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACTIVITY_RECOGNITION,
                    Manifest.permission.POST_NOTIFICATIONS}, REQ_PERM);
        } else {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION,
                    Manifest.permission.ACTIVITY_RECOGNITION}, REQ_PERM);
        }
    }

    /** Chamado na thread principal (via Bridge.startTrack). */
    void beginTrack() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (hasLoc()) {
            startTrackService();
            if (checkSelfPermission(Manifest.permission.ACTIVITY_RECOGNITION) != PackageManager.PERMISSION_GRANTED) {
                requestPerms(); // passos com a tela apagada precisam de "Atividade física"
            }
        } else {
            Track.status = "wait";
            requestPerms();
        }
    }

    /** Chamado na thread principal (via Bridge.stopTrack). */
    void endTrack() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        stopService(new Intent(this, TrackService.class));
        Track.status = "off";
    }

    private void startTrackService() {
        try {
            startForegroundService(new Intent(this, TrackService.class));
        } catch (Exception e) {
            Track.status = "off";
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code != REQ_PERM) return;
        permPending = false;
        if (res.length == 0 || !Track.want) return; // pedido cancelado (ex.: tela girou) ou caminhada já encerrada
        if (hasLoc()) startTrackService();
        else Track.status = "denied";
    }

    // ---------- ciclo de vida e botão voltar ----------

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) {
            web.onResume();
            web.evaluateJavascript("window.__nresume&&__nresume()", null);
        }
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            ViewGroup p = (ViewGroup) web.getParent();
            if (p != null) p.removeView(web);
            web.removeJavascriptInterface("PassoNative");
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web == null) {
            super.onBackPressed();
            return;
        }
        // o app web fecha painéis/volta de aba; se não houver o que fechar, minimiza (a caminhada continua)
        web.evaluateJavascript("(window.__nback&&__nback())?1:0", new ValueCallback<String>() {
            @Override
            public void onReceiveValue(String v) {
                if (!"1".equals(v)) moveTaskToBack(true);
            }
        });
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE) {
            if (fileCb != null) {
                fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
                fileCb = null;
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    // ---------- WebView ----------

    private static String mime(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        if (n.endsWith(".html") || n.endsWith(".htm")) return "text/html";
        if (n.endsWith(".js")) return "application/javascript";
        if (n.endsWith(".css")) return "text/css";
        if (n.endsWith(".json")) return "application/json";
        if (n.endsWith(".png")) return "image/png";
        if (n.endsWith(".svg")) return "image/svg+xml";
        if (n.endsWith(".webp")) return "image/webp";
        if (n.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }

    private class AppClient extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (!HOST.equals(u.getHost())) return null; // internet (Overpass etc.) segue normalmente
            String path = u.getPath();
            if (path == null || path.length() <= 1) path = "/index.html";
            String name = path.substring(1);
            Map<String, String> h = new HashMap<String, String>();
            h.put("Cache-Control", "no-cache");
            try {
                InputStream in = getAssets().open(name);
                return new WebResourceResponse(mime(name), "utf-8", 200, "OK", h, in);
            } catch (IOException e) {
                return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", h,
                        new ByteArrayInputStream(new byte[0]));
            }
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            if (HOST.equals(u.getHost())) return false;
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, u)); // links externos abrem no navegador
            } catch (Exception ignored) {
            }
            return true;
        }

        @Override
        public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
            // o processo de renderização morreu (pouca memória): recria a tela em vez de fechar o app
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    recreate();
                }
            });
            return true;
        }
    }

    private class AppChrome extends WebChromeClient {
        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            boolean ok = hasLoc();
            cb.invoke(origin, ok, false);
            if (!ok) requestPerms();
        }

        @Override
        public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                Intent i = p.createIntent();
                i.setType("*/*"); // alguns seletores escondem .json; o app valida o conteúdo por conta própria
                startActivityForResult(i, REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }
    }
}
