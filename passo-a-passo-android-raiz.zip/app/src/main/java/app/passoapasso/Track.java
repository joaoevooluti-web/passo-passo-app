package app.passoapasso;

import java.util.ArrayList;

/**
 * Estado compartilhado entre o serviço de GPS (que grava as leituras) e a ponte JavaScript
 * (que as entrega ao app web). O serviço continua gravando mesmo com a tela apagada; o app web
 * "puxa" as leituras acumuladas com drain() e as processa em ordem, com o horário original de cada uma.
 */
final class Track {
    private Track() {}

    /** Cada leitura: {lat, lon, precisão (m), velocidade (m/s ou -1), horário (ms desde 1970)}. */
    private static final ArrayList<double[]> BUF = new ArrayList<>();

    /** "off" | "wait" (aguardando permissão) | "ok" | "denied" */
    static volatile String status = "off";
    /** O app web pediu para gravar (startTrack) e ainda não pediu para parar. */
    static volatile boolean want = false;
    /** O serviço em primeiro plano está ativo. */
    static volatile boolean running = false;
    /** Passos contados pelo sensor de passos do Android desde o início da caminhada. */
    static volatile long steps = 0;
    /** O sensor de passos está registrado e com permissão. */
    static volatile boolean stepsOk = false;

    static void add(double lat, double lon, double acc, double speed, long ts) {
        synchronized (BUF) {
            if (BUF.size() >= 40000) BUF.subList(0, 5000).clear(); // ~11 h a 1 leitura/s; só como trava de segurança
            BUF.add(new double[]{lat, lon, acc, speed, (double) ts});
        }
    }

    static void clear() {
        synchronized (BUF) {
            BUF.clear();
        }
    }

    /** Devolve {"st":"ok","f":[[lat,lon,acc,speed,ts],...]} e esvazia o buffer. */
    static String drain() {
        StringBuilder sb = new StringBuilder(96);
        sb.append("{\"st\":\"").append(status).append("\",\"sp\":").append(steps)
                .append(",\"sn\":").append(stepsOk ? 1 : 0).append(",\"f\":[");
        synchronized (BUF) {
            for (int i = 0; i < BUF.size(); i++) {
                double[] f = BUF.get(i);
                if (i > 0) sb.append(',');
                sb.append('[').append(f[0]).append(',').append(f[1]).append(',')
                        .append(Math.round(f[2] * 10.0) / 10.0).append(',')
                        .append(f[3] < 0 ? -1 : Math.round(f[3] * 100.0) / 100.0).append(',')
                        .append((long) f[4]).append(']');
            }
            BUF.clear();
        }
        return sb.append("]}").toString();
    }
}
